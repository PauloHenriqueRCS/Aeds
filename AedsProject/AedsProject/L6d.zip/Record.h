#pragma once

struct Record {
	int num_record;
	Record * prev;
	Record * next;
};