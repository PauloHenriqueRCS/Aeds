#pragma once

struct Node {
	int element;
	Node *next;
	void init(int element);
};
